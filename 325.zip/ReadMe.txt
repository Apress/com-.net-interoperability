Greetings!

First, thanks for buying this text.
I do hope it will help you get 
a clear picture of the COM and .NET
type systems, and how to get these
entities to interop.

A few notes about the example code:

-> I have deleted the Debug, Bin & Obj folders
to reduce the size of the download.

-> Given this, all COM servers will need to
be rebuilt!  Simple open the project file
and rebuild the entire project.  This
will compile and register the COM server.

-> As well, all .NET projects will need
to have external custom references RESET!  

-> All COM+ servers will need to be re-installed
under component services.

-> All .NET code has been compiled against 
the final release of .NET (SP 1).

-> All COM code has been compiled using VC 6.0
and VB 6.0 (with latest SPs).

-> All code was developed on a WinXP Professional
machine.  Things should be just fine on W2K, but
I have not tested any code on 'home' versions of
Windows (Win95, 98, ME) or WinNT.

If you have questions for me regarding this book,
feel free to e-mail me at atroelsen@intertech-inc.com.

Do be aware that I may not be able to answer each and 
every e-mail (due to the nasty element of time).  But I
will certainly do my best!

Anyway, enjoy and take care.

Andrew Troelsen