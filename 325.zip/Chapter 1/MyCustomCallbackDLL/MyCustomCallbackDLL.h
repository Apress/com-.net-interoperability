// The helper macros.

#define MYCUSTOMCALLBACKDLL_API __declspec(dllexport)

// A basic structure.
typedef struct _THEPOINT
{
    int x;
    int y; 
} THEPOINT;
