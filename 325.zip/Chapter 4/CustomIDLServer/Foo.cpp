// Foo.cpp : Implementation of CFoo
#include "stdafx.h"
#include "CustomIDLServer.h"
#include "Foo.h"

/////////////////////////////////////////////////////////////////////////////
// CFoo


STDMETHODIMP CFoo::MethodA()
{
	// TODO: Add your implementation code here

	return S_OK;
}
