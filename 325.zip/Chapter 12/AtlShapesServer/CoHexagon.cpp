// CoHexagon.cpp : Implementation of CCoHexagon
#include "stdafx.h"
#include "AtlShapesServer.h"
#include "CoHexagon.h"

/////////////////////////////////////////////////////////////////////////////
// CCoHexagon


STDMETHODIMP CCoHexagon::Draw(int top, int left, int bottom, int right)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CCoHexagon::SetColor(SHAPECOLOR c)
{
	// TODO: Add your implementation code here

	return S_OK;
}
